<?php
// db.php
$host = 'localhost';
$db = 'it_asset_db';
$user = 'admin'; 
$pass = 'Scl@@2017'; // আগের লাইনে সেমিকোলন মিসিং ছিল কিনা চেক করুন

// MySQLi Connection
$conn = mysqli_connect($host, $user, $pass, $db);

// Check connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
